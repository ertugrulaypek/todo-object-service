from typing import Final

ID: Final = "id"
TITLE: Final = "title"
DESCRIPTION: Final = "description"

TODO_ID_PATH_VARIABLE: Final = "todo_id"